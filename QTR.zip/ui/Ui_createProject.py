# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/home/kronosua/work/QTR/ui/createProject.ui'
#
# Created: Fri Feb  1 15:53:42 2013
#      by: PyQt4 UI code generator 4.9.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(608, 553)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.List = QtGui.QListWidget(Dialog)
        self.List.setEditTriggers(QtGui.QAbstractItemView.CurrentChanged|QtGui.QAbstractItemView.DoubleClicked|QtGui.QAbstractItemView.EditKeyPressed)
        self.List.setDragEnabled(True)
        self.List.setDragDropOverwriteMode(True)
        self.List.setDragDropMode(QtGui.QAbstractItemView.DragDrop)
        self.List.setDefaultDropAction(QtCore.Qt.MoveAction)
        self.List.setSpacing(1)
        self.List.setObjectName(_fromUtf8("List"))
        self.verticalLayout.addWidget(self.List)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.Delete = QtGui.QPushButton(Dialog)
        self.Delete.setObjectName(_fromUtf8("Delete"))
        self.horizontalLayout.addWidget(self.Delete)
        self.Rename = QtGui.QPushButton(Dialog)
        self.Rename.setObjectName(_fromUtf8("Rename"))
        self.horizontalLayout.addWidget(self.Rename)
        self.moveUp = QtGui.QPushButton(Dialog)
        self.moveUp.setObjectName(_fromUtf8("moveUp"))
        self.horizontalLayout.addWidget(self.moveUp)
        self.moveDown = QtGui.QPushButton(Dialog)
        self.moveDown.setObjectName(_fromUtf8("moveDown"))
        self.horizontalLayout.addWidget(self.moveDown)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.Save = QtGui.QPushButton(Dialog)
        self.Save.setObjectName(_fromUtf8("Save"))
        self.horizontalLayout.addWidget(self.Save)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.List.setSortingEnabled(True)
        self.Delete.setText(QtGui.QApplication.translate("Dialog", "Видалити", None, QtGui.QApplication.UnicodeUTF8))
        self.Rename.setText(QtGui.QApplication.translate("Dialog", "Перейменувати", None, QtGui.QApplication.UnicodeUTF8))
        self.moveUp.setText(QtGui.QApplication.translate("Dialog", "Верх", None, QtGui.QApplication.UnicodeUTF8))
        self.moveDown.setText(QtGui.QApplication.translate("Dialog", "Вниз", None, QtGui.QApplication.UnicodeUTF8))
        self.Save.setText(QtGui.QApplication.translate("Dialog", "Зберегти", None, QtGui.QApplication.UnicodeUTF8))


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Dialog = QtGui.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

