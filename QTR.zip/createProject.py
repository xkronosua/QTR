# _*_ coding: utf-8 _*_
from ui.Ui_createProject import Ui_Dialog
from PyQt4 import QtGui
import os
import scipy as sp
from setName import NameDialog
import csv

class ProjectDialog(QtGui.QDialog):
	
	dataList = {}
	defaultIndex = 0
	def __init__(self, parent=None):
		super(ProjectDialog, self).__init__(parent)
		self.ui = Ui_Dialog()
		self.ui.setupUi(self)
		self.uiConnect()
		self.fileDialog = QtGui.QFileDialog(self)
	
	def addToList(self, array, name=''):
		if not name:
			name = 'new' + str(self.defaultIndex)
			self.defaultIndex += 1
		if name not in self.dataList.keys():
			self.dataList.update({name:array})
			self.ui.List.addItem(name)
	
	def Delete(self):
		try:
			current = self.ui.List.currentItem().text()
			item = self.ui.List.takeItem(self.ui.List.currentRow())
			item = None
			del self.dataList[current]
		except AttributeError:
			pass
			
	def Rename(self):
		item = self.ui.List.currentItem()
		old_name = item.text()
		setName = NameDialog(name=old_name)
		setName.exec_()
		new_name = setName.name
		print (new_name)
		item.setText(new_name)
		self.dataList[new_name] = self.dataList[old_name]
		del self.dataList[old_name]
		
	def Save(self):
		
		
		filename = './data/out.dat'#self.fileDialog.getSaveFileName(self,	'Save File')
		
		if filename:
			max_len = 0
			keys = self.dataList.keys()
			headers = []
			
			for i in keys:
				max_len = max(max_len, len(self.dataList[i]))
				headers += ['#X ' + i, '#Y ' + i]
			f = open(filename, 'w')
			writer = csv.writer(f)
			
			writer.writerow(headers)
			for i in range(max_len):
				row = []
				for j in keys:
					val = [sp.nan, sp.nan]
					if len(self.dataList[j]) == max_len or i< len(self.dataList[j]):
						val = self.dataList[j][i, :].tolist()
					row += val
				writer.writerow(row)
			f.close()
			
	def uiConnect(self):
		self.ui.Delete.clicked.connect(self.Delete)
		self.ui.Rename.clicked.connect(self.Rename)
		self.ui.Save.clicked.connect(self.Save)
